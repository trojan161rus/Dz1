package com.trojan.less7;

import javax.swing.*;
import java.awt.*;

public class Map extends JPanel {

    private static JLabel lbl1 = new JLabel();
    public static final int MODE_AI_AI = 1;
    public static final int MODE_HUMAN_AI = 2;
    public static final int MODE_HUMAN_HUMAN = 3;

    Map(){
        setBackground(Color.CYAN);
        lbl1 = new JLabel("");
        add(lbl1,BorderLayout.SOUTH);
    }

     void startNewGame(int mode, int fieldSizeX, int fieldSizeY, int winLen){
         lbl1.setText("M: "+mode+"FSX: "+fieldSizeX+ "FSY: "+fieldSizeY+"WL: "+winLen);
         String i = "1";
         JPanel panel = new JPanel();
         GridLayout layout = new GridLayout(fieldSizeX,fieldSizeY);
         panel.setLayout(layout);
//         add(panel,BorderLayout.CENTER);
        for (int j = 0; j < fieldSizeX; j ++ )
        {
            for (int n = 0; n < fieldSizeY; n ++)
            panel.add(new JButton(i),BorderLayout.SOUTH);
        }


    }
}

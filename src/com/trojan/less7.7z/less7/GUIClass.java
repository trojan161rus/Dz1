package com.trojan.less7;

public class GUIClass {
    public static void main(String[] args) {
        new GameWindow();
    }
}
